package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import com.example.MainActivity
import com.example.R
import com.example.core.RayzeStateStore

class RayzeDnsVpnService : VpnService() {

  private var vpnInterface: ParcelFileDescriptor? = null

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    when (intent?.action) {
      ACTION_STOP -> {
        stopLocalVpn()
        return START_NOT_STICKY
      }
      else -> {
        startForegroundNotification()
        establishLocalDnsVpn()
        return START_STICKY
      }
    }
  }

  private fun startForegroundNotification() {
    runCatching {
      val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
      val channel =
        NotificationChannel(
          CHANNEL_ID,
          "Estabilizador DNS Gamer 1.1.1.1",
          NotificationManager.IMPORTANCE_LOW,
        ).apply {
          description = "Mantém o perfil local DNS 1.1.1.1 ativo"
          setShowBadge(false)
        }
      manager?.createNotificationChannel(channel)

      val openIntent =
        PendingIntent.getActivity(
          this,
          0,
          Intent(this, MainActivity::class.java),
          PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

      val notification =
        Notification.Builder(this, CHANNEL_ID)
          .setContentTitle("Rayze DNS Gamer (1.1.1.1)")
          .setContentText("Estabilizador de ping local ativo")
          .setSmallIcon(R.mipmap.ic_launcher)
          .setContentIntent(openIntent)
          .setOngoing(true)
          .build()

      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
        startForeground(
          NOTIFICATION_ID,
          notification,
          ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE,
        )
      } else {
        startForeground(NOTIFICATION_ID, notification)
      }
    }
  }

  private fun establishLocalDnsVpn() {
    runCatching {
      vpnInterface?.close()
      val builder =
        Builder()
          .setSession("Rayze DNS Gamer 1.1.1.1")
          .setMtu(1500)
          .addAddress("10.88.0.2", 32)
          .addDnsServer("1.1.1.1")
          .addDnsServer("1.0.0.1")

      runCatching { builder.addDisallowedApplication(packageName) }

      vpnInterface = builder.establish()
      RayzeStateStore.setDnsVpnActive(vpnInterface != null)
      if (vpnInterface == null) {
        stopLocalVpn()
      }
    }.onFailure {
      RayzeStateStore.setDnsVpnActive(false)
      stopLocalVpn()
    }
  }

  private fun stopLocalVpn() {
    runCatching { vpnInterface?.close() }
    vpnInterface = null
    RayzeStateStore.setDnsVpnActive(false)
    runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
    runCatching { stopSelf() }
  }

  override fun onRevoke() {
    stopLocalVpn()
    super.onRevoke()
  }

  override fun onDestroy() {
    runCatching { vpnInterface?.close() }
    vpnInterface = null
    RayzeStateStore.setDnsVpnActive(false)
    super.onDestroy()
  }

  companion object {
    const val ACTION_START = "com.raylan.rayzehudfps.action.START_DNS_VPN"
    const val ACTION_STOP = "com.raylan.rayzehudfps.action.STOP_DNS_VPN"
    private const val CHANNEL_ID = "rayze_dns_vpn_channel"
    private const val NOTIFICATION_ID = 2044
  }
}
