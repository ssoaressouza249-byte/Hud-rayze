package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.TypedValue
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.example.MainActivity
import com.example.R
import com.example.core.RayzeStateStore
import com.example.core.RayzeSystemController
import com.example.model.CrosshairColorOption
import com.example.model.CrosshairStyle
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs

class FloatingRayzeService : Service() {

  private var windowManager: WindowManager? = null
  private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

  private var bubbleView: View? = null
  private var bubbleParams: WindowManager.LayoutParams? = null

  private var panelView: View? = null
  private var panelParams: WindowManager.LayoutParams? = null

  private var crosshairView: CrosshairCanvasView? = null
  private var monitorView: TextView? = null

  private var monitorJob: Job? = null
  private var currentFps: Int = 60
  private var frameCount = 0
  private var lastFpsTimestampNs = 0L

  private val fpsFrameCallback =
    object : Choreographer.FrameCallback {
      override fun doFrame(frameTimeNanos: Long) {
        if (monitorView == null) return
        if (lastFpsTimestampNs == 0L) {
          lastFpsTimestampNs = frameTimeNanos
        }
        frameCount++
        val elapsedNs = frameTimeNanos - lastFpsTimestampNs
        if (elapsedNs >= 1_000_000_000L) {
          currentFps = ((frameCount * 1_000_000_000L) / elapsedNs).toInt().coerceIn(1, 240)
          frameCount = 0
          lastFpsTimestampNs = frameTimeNanos
        }
        runCatching { Choreographer.getInstance().postFrameCallback(this) }
      }
    }

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onCreate() {
    super.onCreate()
    startForegroundNotification()
    windowManager = runCatching { getSystemService(Context.WINDOW_SERVICE) as WindowManager }.getOrNull()

    val canOverlay = runCatching { Settings.canDrawOverlays(this) }.getOrDefault(false)
    if (!canOverlay || windowManager == null) {
      RayzeStateStore.setOverlayServiceRunning(false)
      stopSelf()
      return
    }

    RayzeStateStore.setOverlayServiceRunning(true)
    showBubble()
    observeSharedState()
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    if (intent?.action == ACTION_STOP) {
      stopSelf()
      return START_NOT_STICKY
    }
    return START_STICKY
  }

  private fun startForegroundNotification() {
    runCatching {
      val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
      val channel =
        NotificationChannel(
          CHANNEL_ID,
          "Rayze Painel Flutuante",
          NotificationManager.IMPORTANCE_LOW,
        ).apply {
          description = "Mantém a bolinha flutuante RZ e o monitor HUD ativos"
          setShowBadge(false)
        }
      manager?.createNotificationChannel(channel)

      val openIntent =
        PendingIntent.getActivity(
          this,
          1,
          Intent(this, MainActivity::class.java),
          PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

      val notification =
        Notification.Builder(this, CHANNEL_ID)
          .setContentTitle("Rayze HUD & FPS Pro")
          .setContentText("Bolinha RZ flutuante ativa sobre a tela")
          .setSmallIcon(R.mipmap.ic_launcher)
          .setContentIntent(openIntent)
          .setOngoing(true)
          .build()

      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
        startForeground(
          NOTIFICATION_ID,
          notification,
          ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE,
        )
      } else {
        startForeground(NOTIFICATION_ID, notification)
      }
    }
  }

  private fun observeSharedState() {
    serviceScope.launch {
      RayzeStateStore.flags.collectLatest { flags ->
        if (flags.isCrosshairEnabled) {
          ensureCrosshairOverlay(flags.crosshairStyle, flags.crosshairColor)
        } else {
          removeCrosshairOverlay()
        }

        if (flags.isTopMonitorEnabled) {
          ensureTopMonitorOverlay()
        } else {
          removeTopMonitorOverlay()
        }
      }
    }
  }

  private fun dp(value: Int): Int =
    TypedValue.applyDimension(
      TypedValue.COMPLEX_UNIT_DIP,
      value.toFloat(),
      resources.displayMetrics,
    ).toInt()

  private fun showBubble() {
    if (bubbleView != null) return
    runCatching {
      val sizePx = dp(56)
      val view =
        TextView(this).apply {
          text = "RZ"
          setTextColor(COLOR_NEON_RED)
          textSize = 18f
          typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
          gravity = Gravity.CENTER
          background =
            GradientDrawable().apply {
              shape = GradientDrawable.OVAL
              setColor(0xEE080A0F.toInt())
              setStroke(dp(2), COLOR_NEON_RED)
            }
          elevation = dp(8).toFloat()
          contentDescription = "Abrir painel flutuante Rayze"
        }

      val params =
        WindowManager.LayoutParams(
          sizePx,
          sizePx,
          WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
          WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
          PixelFormat.TRANSLUCENT,
        ).apply {
          gravity = Gravity.TOP or Gravity.START
          x = dp(18)
          y = dp(180)
        }

      val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
      var initialX = 0
      var initialY = 0
      var initialTouchX = 0f
      var initialTouchY = 0f
      var isDragging = false

      view.setOnTouchListener { _, event ->
        when (event.action) {
          MotionEvent.ACTION_DOWN -> {
            initialX = params.x
            initialY = params.y
            initialTouchX = event.rawX
            initialTouchY = event.rawY
            isDragging = false
            true
          }
          MotionEvent.ACTION_MOVE -> {
            val dx = (event.rawX - initialTouchX).toInt()
            val dy = (event.rawY - initialTouchY).toInt()
            if (abs(dx) > touchSlop || abs(dy) > touchSlop) {
              isDragging = true
            }
            if (isDragging) {
              params.x = initialX + dx
              params.y = initialY + dy
              runCatching { windowManager?.updateViewLayout(view, params) }
            }
            true
          }
          MotionEvent.ACTION_UP -> {
            if (!isDragging) {
              toggleMiniPanel()
            }
            true
          }
          else -> false
        }
      }

      bubbleView = view
      bubbleParams = params
      windowManager?.addView(view, params)
    }
  }

  private fun toggleMiniPanel() {
    if (panelView != null) {
      removeMiniPanel()
    } else {
      showMiniPanel()
    }
  }

  private fun showMiniPanel() {
    if (panelView != null) return
    runCatching {
      val container =
        LinearLayout(this).apply {
          orientation = LinearLayout.VERTICAL
          setPadding(dp(14), dp(12), dp(14), dp(14))
          background =
            GradientDrawable().apply {
              shape = GradientDrawable.RECTANGLE
              cornerRadius = dp(16).toFloat()
              setColor(0xF5121622.toInt())
              setStroke(dp(2), COLOR_ELECTRIC_CYAN)
            }
        }

      // Header row with title + minimize + close
      val headerRow =
        LinearLayout(this).apply {
          orientation = LinearLayout.HORIZONTAL
          gravity = Gravity.CENTER_VERTICAL
        }

      val titleView =
        TextView(this).apply {
          text = "RAYZE HUD • PAINEL"
          setTextColor(COLOR_ELECTRIC_CYAN)
          textSize = 13f
          typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
          layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

      val minimizeBtn =
        TextView(this).apply {
          text = " — "
          setTextColor(0xFFF5F8FF.toInt())
          textSize = 15f
          typeface = Typeface.DEFAULT_BOLD
          setPadding(dp(10), dp(4), dp(10), dp(4))
          setOnClickListener { removeMiniPanel() }
        }

      val closeServiceBtn =
        TextView(this).apply {
          text = " ✕ "
          setTextColor(COLOR_NEON_RED)
          textSize = 15f
          typeface = Typeface.DEFAULT_BOLD
          setPadding(dp(10), dp(4), dp(6), dp(4))
          setOnClickListener { stopSelf() }
        }

      headerRow.addView(titleView)
      headerRow.addView(minimizeBtn)
      headerRow.addView(closeServiceBtn)
      container.addView(headerRow)

      val statusInfoView =
        TextView(this).apply {
          text = "RAYZE HUD & FPS PRO — Criado por Raylan"
          setTextColor(0xFF9BA7C4.toInt())
          textSize = 10f
          typeface = Typeface.MONOSPACE
          setPadding(0, dp(4), 0, dp(10))
        }
      container.addView(statusInfoView)

      val currentFlags = RayzeStateStore.flags.value

      // 1. Switch Código Legit
      val legitSwitch =
        createCyberSwitchRow(
          label = "1. Código Legit (Mira +50%)",
          checked = currentFlags.isLegitActivated,
        ) { enabled ->
          if (enabled) {
            RayzeSystemController.applyQuickLegitSettings(this)
            RayzeStateStore.setLegitActivated(true)
            statusInfoView.text = "Código Legit ativo • Pointer Speed otimizado ✓"
          } else {
            RayzeStateStore.setLegitActivated(false)
            statusInfoView.text = "Código Legit pausado"
          }
        }
      container.addView(legitSwitch)

      // 2. Switch Mira Flutuante Central
      val crosshairSwitch =
        createCyberSwitchRow(
          label = "2. Mira Flutuante Central",
          checked = currentFlags.isCrosshairEnabled,
        ) { enabled ->
          RayzeStateStore.setCrosshairEnabled(enabled)
        }
      container.addView(crosshairSwitch)

      // Crosshair style & color quick selectors
      val styleRow =
        LinearLayout(this).apply {
          orientation = LinearLayout.HORIZONTAL
          gravity = Gravity.CENTER_VERTICAL
          setPadding(0, dp(2), 0, dp(8))
        }
      CrosshairStyle.entries.forEach { style ->
        val chip =
          TextView(this).apply {
            text = style.label
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            val selected = RayzeStateStore.flags.value.crosshairStyle == style
            setTextColor(if (selected) 0xFF080A0F.toInt() else 0xFFF5F8FF.toInt())
            background =
              GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(if (selected) COLOR_ELECTRIC_CYAN else 0xFF192033.toInt())
              }
            setPadding(dp(10), dp(5), dp(10), dp(5))
            setOnClickListener {
              RayzeStateStore.setCrosshairStyle(style)
              RayzeStateStore.setCrosshairEnabled(true)
              removeMiniPanel()
              showMiniPanel()
            }
          }
        val lp =
          LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT,
          ).apply { marginEnd = dp(6) }
        styleRow.addView(chip, lp)
      }

      CrosshairColorOption.entries.forEach { colorOption ->
        val dot =
          View(this).apply {
            val selected = RayzeStateStore.flags.value.crosshairColor == colorOption
            background =
              GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(colorOption.argb)
                if (selected) setStroke(dp(2), 0xFFFFFFFF.toInt())
              }
            setOnClickListener {
              RayzeStateStore.setCrosshairColor(colorOption)
              RayzeStateStore.setCrosshairEnabled(true)
              removeMiniPanel()
              showMiniPanel()
            }
          }
        val lp =
          LinearLayout.LayoutParams(dp(22), dp(22)).apply {
            marginStart = dp(4)
          }
        styleRow.addView(dot, lp)
      }
      container.addView(styleRow)

      // 3. Switch Monitor Ao Vivo no Topo
      val monitorSwitch =
        createCyberSwitchRow(
          label = "3. Monitor Ao Vivo (FPS/Ping/Temp)",
          checked = currentFlags.isTopMonitorEnabled,
        ) { enabled ->
          RayzeStateStore.setTopMonitorEnabled(enabled)
        }
      container.addView(monitorSwitch)

      // 4. Limpar RAM Agora
      val ramButton =
        Button(this).apply {
          text = "4. LIMPAR RAM AGORA"
          setTextColor(COLOR_ELECTRIC_CYAN)
          textSize = 12f
          typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
          background =
            GradientDrawable().apply {
              cornerRadius = dp(10).toFloat()
              setColor(0xFF192033.toInt())
              setStroke(dp(1), COLOR_ELECTRIC_CYAN)
            }
          setOnClickListener {
            serviceScope.launch {
              val (before, after) = RayzeSystemController.optimizeFpsAndRam(this@FloatingRayzeService)
              val msg = "RAM Livre: $after MB (antes: $before MB) ✓"
              RayzeStateStore.setLastRamCleanMessage(msg)
              statusInfoView.text = msg
              Toast.makeText(this@FloatingRayzeService, msg, Toast.LENGTH_SHORT).show()
            }
          }
        }
      val ramLp =
        LinearLayout.LayoutParams(
          LinearLayout.LayoutParams.MATCH_PARENT,
          dp(42),
        ).apply { topMargin = dp(8) }
      container.addView(ramButton, ramLp)

      // 5. ABRIR FREE FIRE
      val freeFireBtn =
        Button(this).apply {
          text = "ABRIR FREE FIRE"
          setTextColor(0xFFFFFFFF.toInt())
          textSize = 13f
          typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
          background =
            GradientDrawable().apply {
              cornerRadius = dp(10).toFloat()
              setColor(COLOR_NEON_RED)
            }
          setOnClickListener {
            RayzeSystemController.launchFreeFire(this@FloatingRayzeService)
            removeMiniPanel()
          }
        }
      val ffLp =
        LinearLayout.LayoutParams(
          LinearLayout.LayoutParams.MATCH_PARENT,
          dp(46),
        ).apply { topMargin = dp(10) }
      container.addView(freeFireBtn, ffLp)

      val params =
        WindowManager.LayoutParams(
          dp(292),
          WindowManager.LayoutParams.WRAP_CONTENT,
          WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
          WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
          PixelFormat.TRANSLUCENT,
        ).apply {
          gravity = Gravity.CENTER
        }

      panelView = container
      panelParams = params
      windowManager?.addView(container, params)
    }
  }

  private fun createCyberSwitchRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
  ): LinearLayout {
    val row =
      LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(4), 0, dp(4))
      }

    val labelView =
      TextView(this).apply {
        text = label
        setTextColor(0xFFF5F8FF.toInt())
        textSize = 12.5f
        typeface = Typeface.DEFAULT
        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
      }

    @Suppress("DEPRECATION")
    val switchView =
      Switch(this).apply {
        isChecked = checked
        setOnCheckedChangeListener { _, isChecked -> onCheckedChange(isChecked) }
      }

    row.addView(labelView)
    row.addView(switchView)
    return row
  }

  private fun removeMiniPanel() {
    panelView?.let { view ->
      runCatching { windowManager?.removeView(view) }
    }
    panelView = null
    panelParams = null
  }

  private fun ensureCrosshairOverlay(style: CrosshairStyle, color: CrosshairColorOption) {
    val existing = crosshairView
    if (existing != null) {
      existing.updateConfig(style, color.argb)
      return
    }
    runCatching {
      val view = CrosshairCanvasView(this, style, color.argb)
      val sizePx = dp(44)
      val params =
        WindowManager.LayoutParams(
          sizePx,
          sizePx,
          WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
          WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
          PixelFormat.TRANSLUCENT,
        ).apply {
          gravity = Gravity.CENTER
        }
      crosshairView = view
      windowManager?.addView(view, params)
    }
  }

  private fun removeCrosshairOverlay() {
    crosshairView?.let { view ->
      runCatching { windowManager?.removeView(view) }
    }
    crosshairView = null
  }

  private fun ensureTopMonitorOverlay() {
    if (monitorView != null) return
    runCatching {
      val pill =
        TextView(this).apply {
          text = "FPS: --  |  PING: -- ms  |  TEMP: --°C"
          setTextColor(COLOR_ELECTRIC_CYAN)
          textSize = 11.5f
          typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
          setPadding(dp(12), dp(6), dp(12), dp(6))
          background =
            GradientDrawable().apply {
              cornerRadius = dp(20).toFloat()
              setColor(0xDD080A0F.toInt())
              setStroke(dp(1), COLOR_ELECTRIC_CYAN)
            }
        }
      val params =
        WindowManager.LayoutParams(
          WindowManager.LayoutParams.WRAP_CONTENT,
          WindowManager.LayoutParams.WRAP_CONTENT,
          WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
          WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
          PixelFormat.TRANSLUCENT,
        ).apply {
          gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
          y = dp(28)
        }
      monitorView = pill
      windowManager?.addView(pill, params)

      frameCount = 0
      lastFpsTimestampNs = 0L
      runCatching { Choreographer.getInstance().postFrameCallback(fpsFrameCallback) }

      monitorJob?.cancel()
      monitorJob =
        serviceScope.launch {
          while (isActive) {
            val metrics = RayzeSystemController.readMemoryAndBattery(this@FloatingRayzeService)
            val (pingMs, reachable) = RayzeSystemController.measureCloudflarePingMs()
            val pingStr = if (reachable && pingMs != null) "${pingMs}ms" else "--"
            val tempStr = String.format("%.1f°C", metrics.batteryTempC)
            monitorView?.text = "FPS: $currentFps  |  PING: $pingStr  |  TEMP: $tempStr"
            delay(2000L)
          }
        }
    }
  }

  private fun removeTopMonitorOverlay() {
    monitorJob?.cancel()
    monitorJob = null
    runCatching { Choreographer.getInstance().removeFrameCallback(fpsFrameCallback) }
    monitorView?.let { view ->
      runCatching { windowManager?.removeView(view) }
    }
    monitorView = null
  }

  override fun onDestroy() {
    removeMiniPanel()
    removeCrosshairOverlay()
    removeTopMonitorOverlay()
    bubbleView?.let { view ->
      runCatching { windowManager?.removeView(view) }
    }
    bubbleView = null
    RayzeStateStore.setOverlayServiceRunning(false)
    serviceScope.cancel()
    super.onDestroy()
  }

  private class CrosshairCanvasView(
    context: Context,
    private var style: CrosshairStyle,
    private var argbColor: Int,
  ) : View(context) {

    private val strokePaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4.5f
        strokeCap = Paint.Cap.ROUND
      }

    private val fillPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
      }

    fun updateConfig(newStyle: CrosshairStyle, newColor: Int) {
      style = newStyle
      argbColor = newColor
      invalidate()
    }

    override fun onDraw(canvas: Canvas) {
      super.onDraw(canvas)
      val cx = width / 2f
      val cy = height / 2f
      val minSide = minOf(width, height).toFloat()
      strokePaint.color = argbColor
      fillPaint.color = argbColor

      when (style) {
        CrosshairStyle.PONTO -> {
          fillPaint.alpha = 80
          canvas.drawCircle(cx, cy, minSide * 0.20f, fillPaint)
          fillPaint.alpha = 255
          canvas.drawCircle(cx, cy, minSide * 0.09f, fillPaint)
        }
        CrosshairStyle.CRUZ -> {
          val gap = minSide * 0.14f
          val arm = minSide * 0.36f
          canvas.drawLine(cx - arm, cy, cx - gap, cy, strokePaint)
          canvas.drawLine(cx + gap, cy, cx + arm, cy, strokePaint)
          canvas.drawLine(cx, cy - arm, cx, cy - gap, strokePaint)
          canvas.drawLine(cx, cy + gap, cx, cy + arm, strokePaint)
          canvas.drawCircle(cx, cy, minSide * 0.045f, fillPaint)
        }
        CrosshairStyle.CIRCULO -> {
          canvas.drawCircle(cx, cy, minSide * 0.30f, strokePaint)
          canvas.drawCircle(cx, cy, minSide * 0.06f, fillPaint)
        }
      }
    }
  }

  companion object {
    const val ACTION_STOP = "com.raylan.rayzehudfps.action.STOP_FLOATING_HUD"
    private const val CHANNEL_ID = "rayze_floating_overlay_channel"
    private const val NOTIFICATION_ID = 2043
    private const val COLOR_NEON_RED = 0xFFFF1744.toInt()
    private const val COLOR_ELECTRIC_CYAN = 0xFF00E5FF.toInt()
  }
}
