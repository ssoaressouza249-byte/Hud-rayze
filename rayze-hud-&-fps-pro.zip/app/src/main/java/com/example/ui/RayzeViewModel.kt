package com.example.ui

import android.app.Application
import android.content.Intent
import android.net.VpnService
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.RayzeStateStore
import com.example.core.RayzeSystemController
import com.example.model.CrosshairColorOption
import com.example.model.CrosshairStyle
import com.example.model.LegitActivationState
import com.example.model.PermissionStatus
import com.example.model.RayzeSharedFlags
import com.example.model.RayzeTab
import com.example.model.SwipeMetricResult
import com.example.model.SwipeSamplePoint
import com.example.model.TelemetryState
import com.example.model.WeaponPreset
import com.example.model.WeaponPresetCatalog
import com.example.service.FloatingRayzeService
import com.example.service.RayzeDnsVpnService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt

data class RayzeUiState(
  val selectedTab: RayzeTab = RayzeTab.LEGIT_HUD,
  val permissions: PermissionStatus = PermissionStatus(),
  val legitState: LegitActivationState = LegitActivationState.Idle,
  val selectedWeapon: WeaponPreset = WeaponPresetCatalog.presets.first(),
  val fireButtonSizePct: Int = 52,
  val swipeMetric: SwipeMetricResult = SwipeMetricResult(),
  val telemetry: TelemetryState = TelemetryState(),
  val sharedFlags: RayzeSharedFlags = RayzeSharedFlags(),
  val isOptimizingRam: Boolean = false,
  val ramOptimizationSummary: String? = null,
)

class RayzeViewModel(application: Application) : AndroidViewModel(application) {

  private val _uiState = MutableStateFlow(RayzeUiState())
  val uiState: StateFlow<RayzeUiState> = _uiState.asStateFlow()

  private var legitJob: Job? = null
  private var telemetryJob: Job? = null

  init {
    refreshPermissions()
    observeSharedFlags()
    startTelemetryLoop()
  }

  private fun observeSharedFlags() {
    viewModelScope.launch {
      RayzeStateStore.flags.collectLatest { flags ->
        _uiState.update { current ->
          val updatedLegit =
            if (flags.isLegitActivated && current.legitState is LegitActivationState.Idle) {
              LegitActivationState.Activated(pointerSpeedApplied = true, cleanedCacheKb = 0L)
            } else if (!flags.isLegitActivated && current.legitState is LegitActivationState.Activated) {
              LegitActivationState.Idle
            } else {
              current.legitState
            }
          current.copy(sharedFlags = flags, legitState = updatedLegit)
        }
      }
    }
  }

  private fun startTelemetryLoop() {
    telemetryJob?.cancel()
    telemetryJob =
      viewModelScope.launch {
        while (isActive) {
          val ctx = getApplication<Application>()
          val baseTelemetry = RayzeSystemController.readMemoryAndBattery(ctx)
          _uiState.update { state ->
            state.copy(
              telemetry =
                baseTelemetry.copy(
                  pingMs = state.telemetry.pingMs,
                  pingReachable = state.telemetry.pingReachable,
                  isPingChecking = state.telemetry.pingMs == null && state.telemetry.isPingChecking,
                ),
            )
          }

          val (pingMs, reachable) = RayzeSystemController.measureCloudflarePingMs()
          _uiState.update { state ->
            state.copy(
              telemetry =
                state.telemetry.copy(
                  pingMs = pingMs,
                  pingReachable = reachable,
                  isPingChecking = false,
                ),
            )
          }
          delay(2500L)
        }
      }
  }

  fun refreshPermissions() {
    val status = RayzeSystemController.checkPermissions(getApplication())
    _uiState.update { it.copy(permissions = status) }
  }

  fun selectTab(tab: RayzeTab) {
    _uiState.update { it.copy(selectedTab = tab) }
  }

  fun openOverlayPermission() {
    RayzeSystemController.openOverlayPermission(getApplication())
  }

  fun openWriteSettingsPermission() {
    RayzeSystemController.openWriteSettingsPermission(getApplication())
  }

  fun activateLegitCode() {
    if (legitJob?.isActive == true) return
    val ctx = getApplication<Application>()
    legitJob =
      viewModelScope.launch {
        var pointerApplied = false
        var cleanedKb = 0L
        val totalModules = 25

        for (moduleIndex in 1..totalModules) {
          val progress = (moduleIndex * 100) / totalModules
          _uiState.update {
            it.copy(
              legitState =
                LegitActivationState.Activating(
                  progressPercent = progress,
                  completedModules = moduleIndex,
                  totalModules = totalModules,
                ),
            )
          }

          val (stepPointer, stepCleanedKb) =
            RayzeSystemController.applyLegitCalibrationStep(ctx, moduleIndex)
          if (stepPointer) pointerApplied = true
          cleanedKb += stepCleanedKb
          delay(65L)
        }

        RayzeStateStore.setLegitActivated(true)
        _uiState.update {
          it.copy(
            legitState =
              LegitActivationState.Activated(
                pointerSpeedApplied = pointerApplied,
                cleanedCacheKb = cleanedKb,
              ),
          )
        }
      }
  }

  fun selectWeaponPreset(preset: WeaponPreset) {
    _uiState.update {
      it.copy(
        selectedWeapon = preset,
        fireButtonSizePct = preset.tamanhoBotaoPct.coerceIn(40, 80),
      )
    }
  }

  fun updateFireButtonSize(sizePct: Int) {
    _uiState.update { it.copy(fireButtonSizePct = sizePct.coerceIn(40, 80)) }
  }

  fun updateSwipeLiveTrail(points: List<SwipeSamplePoint>, elapsedMs: Long) {
    val result = computeSwipeMetrics(points, elapsedMs)
    _uiState.update { it.copy(swipeMetric = result) }
  }

  fun finalizeSwipe(points: List<SwipeSamplePoint>, elapsedMs: Long) {
    val result = computeSwipeMetrics(points, elapsedMs)
    _uiState.update { it.copy(swipeMetric = result) }
  }

  private fun computeSwipeMetrics(
    points: List<SwipeSamplePoint>,
    elapsedMs: Long,
  ): SwipeMetricResult {
    if (points.size < 2) {
      return SwipeMetricResult(
        durationMs = elapsedMs,
        straightnessPercent = 0,
        upwardDistanceDp = 0f,
        hasMeasurement = false,
        trail = points,
      )
    }
    val start = points.first()
    val end = points.last()
    val netUpwardY = start.y - end.y // positive when swiping UP
    if (netUpwardY <= 8f) {
      return SwipeMetricResult(
        durationMs = elapsedMs,
        straightnessPercent = 0,
        upwardDistanceDp = 0f,
        hasMeasurement = true,
        trail = points,
      )
    }

    var totalPathLength = 0f
    var maxHorizontalDeviation = 0f
    for (i in 1 until points.size) {
      val prev = points[i - 1]
      val curr = points[i]
      totalPathLength += hypot(curr.x - prev.x, curr.y - prev.y)
      maxHorizontalDeviation = maxOf(maxHorizontalDeviation, abs(curr.x - start.x))
    }

    val directDistance = hypot(end.x - start.x, end.y - start.y).coerceAtLeast(1f)
    val pathEfficiency = (netUpwardY / totalPathLength.coerceAtLeast(1f)).coerceIn(0f, 1f)
    val lateralPenalty = (maxHorizontalDeviation / directDistance).coerceIn(0f, 1f) * 0.45f
    val straightness = ((pathEfficiency - lateralPenalty) * 100f).roundToInt().coerceIn(0, 100)

    val density = getApplication<Application>().resources.displayMetrics.density.coerceAtLeast(1f)
    return SwipeMetricResult(
      durationMs = elapsedMs.coerceAtLeast(1L),
      straightnessPercent = straightness,
      upwardDistanceDp = netUpwardY / density,
      hasMeasurement = true,
      trail = points,
    )
  }

  fun toggleFloatingOverlayService() {
    val ctx = getApplication<Application>()
    val perms = RayzeSystemController.checkPermissions(ctx)
    _uiState.update { it.copy(permissions = perms) }

    if (!perms.canDrawOverlays) {
      RayzeSystemController.openOverlayPermission(ctx)
      return
    }

    val isRunning = RayzeStateStore.flags.value.isOverlayServiceRunning
    runCatching {
      if (isRunning) {
        val stopIntent =
          Intent(ctx, FloatingRayzeService::class.java).apply {
            action = FloatingRayzeService.ACTION_STOP
          }
        ctx.startService(stopIntent)
      } else {
        val startIntent = Intent(ctx, FloatingRayzeService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
          ctx.startForegroundService(startIntent)
        } else {
          ctx.startService(startIntent)
        }
      }
    }
  }

  fun setCrosshairStyle(style: CrosshairStyle) {
    RayzeStateStore.setCrosshairStyle(style)
  }

  fun setCrosshairColor(color: CrosshairColorOption) {
    RayzeStateStore.setCrosshairColor(color)
  }

  fun prepareVpnIntent(): Intent? {
    return runCatching { VpnService.prepare(getApplication()) }.getOrNull()
  }

  fun setDnsVpnEnabled(enabled: Boolean) {
    val ctx = getApplication<Application>()
    runCatching {
      val intent =
        Intent(ctx, RayzeDnsVpnService::class.java).apply {
          action =
            if (enabled) RayzeDnsVpnService.ACTION_START else RayzeDnsVpnService.ACTION_STOP
        }
      if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        ctx.startForegroundService(intent)
      } else {
        ctx.startService(intent)
      }
    }
  }

  fun optimizeFpsAndRam() {
    if (_uiState.value.isOptimizingRam) return
    val ctx = getApplication<Application>()
    viewModelScope.launch {
      _uiState.update { it.copy(isOptimizingRam = true) }
      val (beforeMb, afterMb) = RayzeSystemController.optimizeFpsAndRam(ctx)
      val updatedTelemetry = RayzeSystemController.readMemoryAndBattery(ctx)
      val summary = "RAM Livre: $afterMb MB (antes: $beforeMb MB) • Desempenho Ativo ✓"
      RayzeStateStore.setLastRamCleanMessage(summary)
      _uiState.update { state ->
        state.copy(
          isOptimizingRam = false,
          ramOptimizationSummary = summary,
          telemetry =
            updatedTelemetry.copy(
              pingMs = state.telemetry.pingMs,
              pingReachable = state.telemetry.pingReachable,
              isPingChecking = state.telemetry.isPingChecking,
            ),
        )
      }
    }
  }

  fun launchFreeFire() {
    RayzeSystemController.launchFreeFire(getApplication())
  }
}
