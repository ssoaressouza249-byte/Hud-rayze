package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.LegitActivationState
import com.example.model.SwipeMetricResult
import com.example.model.SwipeSamplePoint
import com.example.model.WeaponPreset
import com.example.model.WeaponPresetCatalog
import com.example.ui.components.CyberGlowCard
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberGreenDark
import com.example.ui.theme.CyberSurfaceBorder
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.CyberVoidBlack
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.NeonRed
import kotlin.math.hypot
import kotlin.math.roundToInt

@Composable
fun LegitHudTab(
  legitState: LegitActivationState,
  selectedWeapon: WeaponPreset,
  fireButtonSizePct: Int,
  swipeMetric: SwipeMetricResult,
  onActivateLegit: () -> Unit,
  onSelectWeapon: (WeaponPreset) -> Unit,
  onFireButtonSizeChange: (Int) -> Unit,
  onLiveSwipeUpdate: (List<SwipeSamplePoint>, Long) -> Unit,
  onSwipeFinished: (List<SwipeSamplePoint>, Long) -> Unit,
  modifier: Modifier = Modifier,
) {
  Column(
    modifier = modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    // 1. Código Legit Main Card
    LegitActivationCard(
      legitState = legitState,
      onActivateLegit = onActivateLegit,
    )

    // 2. Weapon Sensitivity Presets Card
    WeaponPresetsCard(
      selectedWeapon = selectedWeapon,
      onSelectWeapon = onSelectWeapon,
    )

    // 3. Interactive Fire Button Calibrator Card
    FireButtonCalibratorCard(
      buttonSizePct = fireButtonSizePct,
      swipeMetric = swipeMetric,
      onSizeChange = onFireButtonSizeChange,
      onLiveSwipeUpdate = onLiveSwipeUpdate,
      onSwipeFinished = onSwipeFinished,
    )
  }
}

@Composable
private fun LegitActivationCard(
  legitState: LegitActivationState,
  onActivateLegit: () -> Unit,
) {
  CyberGlowCard(borderAccent = NeonRed) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Icon(
        imageVector = Icons.Filled.Bolt,
        contentDescription = null,
        tint = NeonRed,
        modifier = Modifier.size(22.dp),
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = stringResource(R.string.legit_section_title),
        style = MaterialTheme.typography.titleLarge,
        fontSize = 16.sp,
        color = CyberTextPrimary,
      )
    }

    Spacer(modifier = Modifier.height(12.dp))

    Button(
      onClick = onActivateLegit,
      enabled = legitState !is LegitActivationState.Activating,
      shape = RoundedCornerShape(12.dp),
      colors =
        ButtonDefaults.buttonColors(
          containerColor = NeonRed,
          contentColor = Color.White,
          disabledContainerColor = CyberSurfaceElevated,
          disabledContentColor = ElectricCyan,
        ),
      modifier =
        Modifier
          .fillMaxWidth()
          .height(54.dp)
          .testTag("activate_legit_button"),
    ) {
      Icon(
        imageVector = Icons.Filled.GpsFixed,
        contentDescription = null,
        modifier = Modifier.size(20.dp),
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = stringResource(R.string.legit_main_button),
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 12.sp,
        textAlign = TextAlign.Center,
      )
    }

    AnimatedVisibility(visible = legitState is LegitActivationState.Activating) {
      val activating = legitState as? LegitActivationState.Activating
      val targetFraction = (activating?.progressPercent ?: 0) / 100f
      val smoothProgress by
        animateFloatAsState(
          targetValue = targetFraction,
          animationSpec = tween(durationMillis = 80),
          label = "legit_progress",
        )

      Column(modifier = Modifier.fillMaxWidth().padding(top = 14.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text(
            text = "Ativando... (${activating?.progressPercent ?: 0}%)",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 12.5.sp,
            color = ElectricCyan,
          )
          Text(
            text = "0% - 100%",
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = CyberTextSecondary,
          )
        }
        Spacer(modifier = Modifier.height(8.dp))
        LinearProgressIndicator(
          progress = { smoothProgress },
          modifier =
            Modifier
              .fillMaxWidth()
              .height(10.dp)
              .clip(RoundedCornerShape(50))
              .testTag("legit_progress_bar"),
          color = ElectricCyan,
          trackColor = CyberVoidBlack,
        )
      }
    }

    AnimatedVisibility(visible = legitState is LegitActivationState.Activated) {
      val activated = legitState as? LegitActivationState.Activated
      Surface(
        modifier =
          Modifier
            .fillMaxWidth()
            .padding(top = 14.dp)
            .testTag("legit_activated_badge"),
        shape = RoundedCornerShape(12.dp),
        color = CyberGreenDark,
        border = BorderStroke(1.dp, CyberGreen),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.Center,
        ) {
          Icon(
            imageVector = Icons.Filled.CheckCircle,
            contentDescription = null,
            tint = CyberGreen,
            modifier = Modifier.size(20.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Column {
            Text(
              text = stringResource(R.string.legit_activated_badge),
              color = CyberGreen,
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.ExtraBold,
              fontSize = 13.sp,
            )
            if (activated != null) {
              val speedNote =
                if (activated.pointerSpeedApplied) {
                  "Pointer Speed 7 aplicado no sistema"
                } else {
                  "25 módulos de toque calibrados (conceda Modificar Config. para Pointer Speed)"
                }
              Text(
                text = speedNote,
                color = CyberTextPrimary.copy(alpha = 0.85f),
                fontSize = 11.sp,
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun WeaponPresetsCard(
  selectedWeapon: WeaponPreset,
  onSelectWeapon: (WeaponPreset) -> Unit,
) {
  CyberGlowCard(borderAccent = ElectricCyan) {
    Text(
      text = stringResource(R.string.weapon_presets_title),
      style = MaterialTheme.typography.titleMedium,
      color = CyberTextPrimary,
    )
    Spacer(modifier = Modifier.height(10.dp))

    Row(
      modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      WeaponPresetCatalog.presets.forEach { preset ->
        val selected = preset.id == selectedWeapon.id
        FilterChip(
          selected = selected,
          onClick = { onSelectWeapon(preset) },
          label = {
            Text(
              text = preset.name,
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp,
            )
          },
          colors =
            FilterChipDefaults.filterChipColors(
              containerColor = CyberSurfaceElevated,
              labelColor = CyberTextSecondary,
              selectedContainerColor = NeonRed.copy(alpha = 0.22f),
              selectedLabelColor = NeonRed,
            ),
          border =
            FilterChipDefaults.filterChipBorder(
              enabled = true,
              selected = selected,
              borderColor = CyberSurfaceBorder,
              selectedBorderColor = NeonRed,
            ),
          modifier = Modifier.testTag("weapon_chip_${preset.id}"),
        )
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    Surface(
      shape = RoundedCornerShape(12.dp),
      color = CyberSurfaceElevated,
      border = BorderStroke(1.dp, CyberSurfaceBorder),
      modifier = Modifier.fillMaxWidth(),
    ) {
      Column(modifier = Modifier.padding(12.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = "${selectedWeapon.name} • ${selectedWeapon.category}",
            color = ElectricCyan,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 12.5.sp,
          )
          Text(
            text = "DPI ${selectedWeapon.dpiRecomendada}",
            color = NeonRed,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          SensitivityStatPill("Geral", "${selectedWeapon.geral}", Modifier.weight(1f))
          SensitivityStatPill("Red Dot", "${selectedWeapon.pontoVermelho}", Modifier.weight(1f))
          SensitivityStatPill("2x", "${selectedWeapon.mira2x}", Modifier.weight(1f))
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          SensitivityStatPill("4x", "${selectedWeapon.mira4x}", Modifier.weight(1f))
          SensitivityStatPill("AWM", "${selectedWeapon.awm}", Modifier.weight(1f))
          SensitivityStatPill("Botão", "${selectedWeapon.tamanhoBotaoPct}%", Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = selectedWeapon.tip,
          style = MaterialTheme.typography.bodyMedium,
          color = CyberTextSecondary,
          fontSize = 11.5.sp,
        )
      }
    }
  }
}

@Composable
private fun SensitivityStatPill(
  label: String,
  value: String,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(8.dp),
    color = CyberVoidBlack,
    border = BorderStroke(0.75.dp, CyberSurfaceBorder),
  ) {
    Column(
      modifier = Modifier.padding(vertical = 6.dp, horizontal = 8.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Text(
        text = label,
        color = CyberTextMuted,
        fontSize = 10.sp,
        fontFamily = FontFamily.Default,
      )
      Text(
        text = value,
        color = CyberTextPrimary,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        fontSize = 13.5.sp,
      )
    }
  }
}

@Composable
private fun FireButtonCalibratorCard(
  buttonSizePct: Int,
  swipeMetric: SwipeMetricResult,
  onSizeChange: (Int) -> Unit,
  onLiveSwipeUpdate: (List<SwipeSamplePoint>, Long) -> Unit,
  onSwipeFinished: (List<SwipeSamplePoint>, Long) -> Unit,
) {
  val density = LocalDensity.current
  val buttonDiameterDp = (48f + ((buttonSizePct - 40) / 40f) * 48f).dp
  val buttonRadiusPx = with(density) { (buttonDiameterDp / 2).toPx() }

  var boxSize by remember { mutableStateOf(IntSize.Zero) }
  val activeTrail = remember { mutableStateListOf<SwipeSamplePoint>() }
  var startTimeMs by remember { mutableLongStateOf(0L) }

  CyberGlowCard(borderAccent = NeonRed) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Filled.TouchApp,
          contentDescription = null,
          tint = NeonRed,
          modifier = Modifier.size(20.dp),
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = stringResource(R.string.calibrator_title),
          style = MaterialTheme.typography.titleMedium,
          color = CyberTextPrimary,
        )
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Slider for 40% - 80% button size
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = stringResource(R.string.calibrator_size_label),
        style = MaterialTheme.typography.bodyMedium,
        color = CyberTextSecondary,
      )
      Text(
        text = "$buttonSizePct%",
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        color = ElectricCyan,
        fontSize = 14.sp,
      )
    }

    Slider(
      value = buttonSizePct.toFloat(),
      onValueChange = { onSizeChange(it.roundToInt()) },
      valueRange = 40f..80f,
      colors =
        SliderDefaults.colors(
          thumbColor = NeonRed,
          activeTrackColor = NeonRed,
          inactiveTrackColor = CyberSurfaceBorder,
        ),
      modifier = Modifier.testTag("fire_button_size_slider"),
    )

    // Live Metrics Row
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      MetricBadge(
        label = stringResource(R.string.calibrator_time_label),
        value = if (swipeMetric.hasMeasurement) "${swipeMetric.durationMs} ms" else "-- ms",
        accent = ElectricCyan,
        modifier = Modifier.weight(1f),
      )
      MetricBadge(
        label = stringResource(R.string.calibrator_straightness_label),
        value = if (swipeMetric.hasMeasurement) "${swipeMetric.straightnessPercent}%" else "--%",
        accent =
          when {
            !swipeMetric.hasMeasurement -> CyberTextSecondary
            swipeMetric.straightnessPercent >= 85 -> CyberGreen
            swipeMetric.straightnessPercent >= 60 -> ElectricCyan
            else -> NeonRed
          },
        modifier = Modifier.weight(1f),
      )
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Interactive HUD Swipe Test Arena
    Box(
      modifier =
        Modifier
          .fillMaxWidth()
          .height(220.dp)
          .clip(RoundedCornerShape(14.dp))
          .background(
            Brush.verticalGradient(
              colors = listOf(CyberVoidBlack, Color(0xFF0E1320)),
            ),
          )
          .border(1.dp, CyberSurfaceBorder, RoundedCornerShape(14.dp))
          .onSizeChanged { boxSize = it }
          .pointerInput(boxSize, buttonRadiusPx) {
            awaitPointerEventScope {
              while (true) {
                val downEvent = awaitPointerEvent(PointerEventPass.Initial)
                val downChange = downEvent.changes.firstOrNull { it.pressed } ?: continue

                val centerX = boxSize.width / 2f
                val bottomMarginPx = with(density) { 26.dp.toPx() }
                val centerY = (boxSize.height - bottomMarginPx - buttonRadiusPx).coerceAtLeast(buttonRadiusPx)

                val distFromBtn =
                  hypot(downChange.position.x - centerX, downChange.position.y - centerY)
                if (distFromBtn <= buttonRadiusPx * 1.45f) {
                  downChange.consume()
                  activeTrail.clear()
                  activeTrail.add(SwipeSamplePoint(downChange.position.x, downChange.position.y))
                  startTimeMs = android.os.SystemClock.elapsedRealtime()
                  onLiveSwipeUpdate(activeTrail.toList(), 0L)

                  var tracking = true
                  while (tracking) {
                    val moveEvent = awaitPointerEvent(PointerEventPass.Initial)
                    val moveChange =
                      moveEvent.changes.firstOrNull { it.id == downChange.id }
                        ?: moveEvent.changes.firstOrNull()
                    if (moveChange == null || !moveChange.pressed) {
                      tracking = false
                      moveChange?.consume()
                      val totalMs = android.os.SystemClock.elapsedRealtime() - startTimeMs
                      onSwipeFinished(activeTrail.toList(), totalMs)
                    } else {
                      moveChange.consume()
                      activeTrail.add(SwipeSamplePoint(moveChange.position.x, moveChange.position.y))
                      val elapsed = android.os.SystemClock.elapsedRealtime() - startTimeMs
                      onLiveSwipeUpdate(activeTrail.toList(), elapsed)
                    }
                  }
                }
              }
            }
          }
          .testTag("fire_button_test_arena"),
    ) {
      // Guide grid + upward direction line + live swipe trail
      Canvas(modifier = Modifier.fillMaxSize()) {
        val centerX = size.width / 2f
        val bottomMargin = 26.dp.toPx()
        val btnCenterY = (size.height - bottomMargin - buttonRadiusPx).coerceAtLeast(buttonRadiusPx)

        // Vertical ideal guide line
        drawLine(
          color = ElectricCyan.copy(alpha = 0.22f),
          start = Offset(centerX, btnCenterY),
          end = Offset(centerX, 20.dp.toPx()),
          strokeWidth = 2.dp.toPx(),
        )
        // Target head zone circle at top
        drawCircle(
          color = ElectricCyan.copy(alpha = 0.28f),
          radius = 16.dp.toPx(),
          center = Offset(centerX, 26.dp.toPx()),
          style = Stroke(width = 1.5.dp.toPx()),
        )

        val trailToDraw = if (activeTrail.isNotEmpty()) activeTrail else swipeMetric.trail
        if (trailToDraw.size >= 2) {
          val path =
            Path().apply {
              moveTo(trailToDraw.first().x, trailToDraw.first().y)
              for (i in 1 until trailToDraw.size) {
                lineTo(trailToDraw[i].x, trailToDraw[i].y)
              }
            }
          drawPath(
            path = path,
            color = CyberGreen,
            style = Stroke(width = 3.5.dp.toPx(), cap = StrokeCap.Round),
          )
        }
      }

      Text(
        text = stringResource(R.string.calibrator_hint),
        color = CyberTextMuted,
        fontSize = 11.sp,
        modifier = Modifier.align(Alignment.TopCenter).padding(top = 8.dp),
      )

      // Adjustable Fire Button inside arena
      Box(
        modifier =
          Modifier
            .align(Alignment.BottomCenter)
            .padding(bottom = 26.dp)
            .size(buttonDiameterDp)
            .clip(CircleShape)
            .background(
              Brush.radialGradient(
                colors = listOf(NeonRed.copy(alpha = 0.35f), NeonRed.copy(alpha = 0.14f)),
              ),
            )
            .border(2.dp, NeonRed, CircleShape),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Filled.GpsFixed,
          contentDescription = "Botão de atirar calibrável",
          tint = Color.White,
          modifier = Modifier.size((buttonDiameterDp.value * 0.45f).dp),
        )
      }
    }
  }
}

@Composable
private fun MetricBadge(
  label: String,
  value: String,
  accent: Color,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(10.dp),
    color = CyberSurfaceElevated,
    border = BorderStroke(1.dp, accent.copy(alpha = 0.45f)),
  ) {
    Column(
      modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Text(
        text = label,
        color = CyberTextSecondary,
        fontSize = 11.sp,
      )
      Text(
        text = value,
        color = accent,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 16.sp,
      )
    }
  }
}
