package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.NetworkPing
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.VpnLock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.TelemetryState
import com.example.ui.components.CyberGlowCard
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberGreenDark
import com.example.ui.theme.CyberSurfaceBorder
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.CyberVoidBlack
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.NeonRed

@Composable
fun FpsPingTab(
  telemetry: TelemetryState,
  isDnsVpnActive: Boolean,
  isOptimizingRam: Boolean,
  ramOptimizationSummary: String?,
  onToggleDnsVpn: (Boolean) -> Unit,
  onOptimizeFpsAndRam: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Column(
    modifier = modifier.fillMaxWidth(),
    verticalArrangement = Arrangement.spacedBy(14.dp),
  ) {
    // 1. Live Telemetry Card (RAM, Battery Temp, Ping 1.1.1.1)
    CyberGlowCard(borderAccent = ElectricCyan) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Filled.Memory,
          contentDescription = null,
          tint = ElectricCyan,
          modifier = Modifier.size(20.dp),
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = stringResource(R.string.telemetry_title),
          style = MaterialTheme.typography.titleLarge,
          fontSize = 16.sp,
          color = CyberTextPrimary,
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        TelemetryStatTile(
          icon = Icons.Filled.Memory,
          label = stringResource(R.string.telemetry_ram),
          value = "${telemetry.freeRamMb} MB",
          subValue = "Total: ${telemetry.totalRamMb} MB",
          accent = ElectricCyan,
          modifier = Modifier.weight(1f),
        )

        val tempColor =
          when {
            telemetry.batteryTempC >= 42f -> NeonRed
            telemetry.batteryTempC >= 37f -> CyberAmber
            else -> CyberGreen
          }
        TelemetryStatTile(
          icon = Icons.Filled.BatteryChargingFull,
          label = stringResource(R.string.telemetry_temp),
          value = String.format("%.1f °C", telemetry.batteryTempC),
          subValue = "${telemetry.batteryLevelPct}% • ${telemetry.thermalLabel}",
          accent = tempColor,
          modifier = Modifier.weight(1f),
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      // RAM usage progress bar
      Column(modifier = Modifier.fillMaxWidth()) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text(
            text = "Uso de Memória RAM",
            style = MaterialTheme.typography.bodyMedium,
            fontSize = 11.5.sp,
            color = CyberTextSecondary,
          )
          Text(
            text = "${(telemetry.ramUsedFraction * 100f).toInt()}%",
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 11.5.sp,
            color = ElectricCyan,
          )
        }
        Spacer(modifier = Modifier.height(6.dp))
        LinearProgressIndicator(
          progress = { telemetry.ramUsedFraction },
          modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)),
          color = ElectricCyan,
          trackColor = CyberVoidBlack,
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Ping 1.1.1.1 Row
      val pingText =
        when {
          telemetry.isPingChecking -> "Medindo..."
          telemetry.pingReachable && telemetry.pingMs != null -> "${telemetry.pingMs} ms"
          else -> "Sem resposta ICMP"
        }
      val pingColor =
        when {
          telemetry.isPingChecking -> CyberTextSecondary
          telemetry.pingReachable && (telemetry.pingMs ?: 999L) <= 60L -> CyberGreen
          telemetry.pingReachable -> CyberAmber
          else -> NeonRed
        }

      Surface(
        shape = RoundedCornerShape(12.dp),
        color = CyberSurfaceElevated,
        border = BorderStroke(1.dp, pingColor.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Filled.NetworkPing,
              contentDescription = null,
              tint = pingColor,
              modifier = Modifier.size(20.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = stringResource(R.string.telemetry_ping),
                style = MaterialTheme.typography.titleMedium,
                fontSize = 13.sp,
                color = CyberTextPrimary,
              )
              Text(
                text = "InetAddress.getByName(\"1.1.1.1\")",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.5.sp,
                color = CyberTextSecondary,
              )
            }
          }

          Text(
            text = pingText,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 15.sp,
            color = pingColor,
            modifier = Modifier.testTag("live_ping_value"),
          )
        }
      }
    }

    // 2. DNS 1.1.1.1 Local VPN Switch Card
    CyberGlowCard(borderAccent = if (isDnsVpnActive) CyberGreen else ElectricCyan) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Icon(
          imageVector = Icons.Filled.VpnLock,
          contentDescription = null,
          tint = if (isDnsVpnActive) CyberGreen else ElectricCyan,
          modifier = Modifier.size(24.dp),
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = stringResource(R.string.vpn_switch_title),
            style = MaterialTheme.typography.titleMedium,
            color = CyberTextPrimary,
          )
          Text(
            text = stringResource(R.string.vpn_switch_desc),
            style = MaterialTheme.typography.bodyMedium,
            fontSize = 11.5.sp,
            color = CyberTextSecondary,
          )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Switch(
          checked = isDnsVpnActive,
          onCheckedChange = onToggleDnsVpn,
          colors =
            SwitchDefaults.colors(
              checkedThumbColor = CyberVoidBlack,
              checkedTrackColor = CyberGreen,
              uncheckedThumbColor = CyberTextSecondary,
              uncheckedTrackColor = CyberSurfaceElevated,
            ),
          modifier = Modifier.testTag("dns_vpn_switch"),
        )
      }
    }

    // 3. Optimize FPS & Clean RAM Card
    CyberGlowCard(borderAccent = NeonRed) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Filled.RocketLaunch,
          contentDescription = null,
          tint = NeonRed,
          modifier = Modifier.size(20.dp),
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "Motor de Desempenho & Memória",
          style = MaterialTheme.typography.titleMedium,
          color = CyberTextPrimary,
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      Button(
        onClick = onOptimizeFpsAndRam,
        enabled = !isOptimizingRam,
        shape = RoundedCornerShape(12.dp),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = NeonRed,
            contentColor = Color.White,
            disabledContainerColor = CyberSurfaceElevated,
            disabledContentColor = ElectricCyan,
          ),
        modifier = Modifier.fillMaxWidth().height(54.dp).testTag("optimize_fps_ram_button"),
      ) {
        if (isOptimizingRam) {
          CircularProgressIndicator(
            modifier = Modifier.size(18.dp),
            strokeWidth = 2.dp,
            color = ElectricCyan,
          )
        } else {
          Icon(
            imageVector = Icons.Filled.CleaningServices,
            contentDescription = null,
            modifier = Modifier.size(20.dp),
          )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = stringResource(R.string.fps_boost_button),
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.ExtraBold,
          fontSize = 13.sp,
        )
      }

      AnimatedVisibility(visible = ramOptimizationSummary != null) {
        Surface(
          shape = RoundedCornerShape(10.dp),
          color = CyberGreenDark,
          border = BorderStroke(1.dp, CyberGreen),
          modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
        ) {
          Text(
            text = ramOptimizationSummary ?: stringResource(R.string.fps_boost_done),
            color = CyberGreen,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            modifier = Modifier.padding(12.dp),
          )
        }
      }
    }
  }
}

@Composable
private fun TelemetryStatTile(
  icon: ImageVector,
  label: String,
  value: String,
  subValue: String,
  accent: Color,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(12.dp),
    color = CyberSurfaceElevated,
    border = BorderStroke(1.dp, CyberSurfaceBorder),
  ) {
    Column(modifier = Modifier.padding(12.dp)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = icon,
          contentDescription = null,
          tint = accent,
          modifier = Modifier.size(16.dp),
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = label,
          style = MaterialTheme.typography.bodyMedium,
          fontSize = 11.5.sp,
          color = CyberTextSecondary,
        )
      }
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = value,
        color = accent,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 18.sp,
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = subValue,
        color = CyberTextSecondary,
        fontSize = 10.5.sp,
      )
    }
  }
}
