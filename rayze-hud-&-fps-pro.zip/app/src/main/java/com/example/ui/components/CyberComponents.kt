package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.PermissionStatus
import com.example.ui.theme.CyberCardSurface
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberGreenDark
import com.example.ui.theme.CyberSurfaceBorder
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.CyberVoidBlack
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.NeonRed

@Composable
fun CyberGlowCard(
  modifier: Modifier = Modifier,
  borderAccent: Color = ElectricCyan,
  content: @Composable ColumnScope.() -> Unit,
) {
  Surface(
    modifier = modifier.fillMaxWidth(),
    shape = RoundedCornerShape(16.dp),
    color = CyberCardSurface,
    border =
      BorderStroke(
        width = 1.dp,
        brush =
          Brush.linearGradient(
            colors =
              listOf(
                borderAccent.copy(alpha = 0.65f),
                CyberSurfaceBorder,
                NeonRed.copy(alpha = 0.35f),
              ),
          ),
      ),
    tonalElevation = 4.dp,
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      content = content,
    )
  }
}

@Composable
fun RayzeBrandBanner(modifier: Modifier = Modifier) {
  Surface(
    modifier = modifier.fillMaxWidth(),
    color = CyberVoidBlack,
    border =
      BorderStroke(
        width = 0.75.dp,
        brush = Brush.horizontalGradient(listOf(NeonRed.copy(alpha = 0.5f), ElectricCyan.copy(alpha = 0.5f))),
      ),
    shape = RoundedCornerShape(12.dp),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.Center,
    ) {
      Box(
        modifier =
          Modifier
            .size(8.dp)
            .background(NeonRed, CircleShape),
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = stringResource(R.string.brand_signature),
        color = CyberTextPrimary,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        fontSize = 11.sp,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
      Spacer(modifier = Modifier.width(8.dp))
      Box(
        modifier =
          Modifier
            .size(8.dp)
            .background(ElectricCyan, CircleShape),
      )
    }
  }
}

@Composable
fun PermissionsCard(
  status: PermissionStatus,
  onOpenOverlayPermission: () -> Unit,
  onOpenWriteSettingsPermission: () -> Unit,
  modifier: Modifier = Modifier,
) {
  CyberGlowCard(modifier = modifier, borderAccent = ElectricCyan) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Icon(
        imageVector = Icons.Filled.Shield,
        contentDescription = null,
        tint = ElectricCyan,
        modifier = Modifier.size(20.dp),
      )
      Spacer(modifier = Modifier.width(8.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = stringResource(R.string.permissions_title),
          style = MaterialTheme.typography.titleMedium,
          color = CyberTextPrimary,
        )
        Text(
          text = stringResource(R.string.permissions_subtitle),
          style = MaterialTheme.typography.bodyMedium,
          color = CyberTextSecondary,
          fontSize = 11.5.sp,
        )
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    PermissionActionRow(
      icon = Icons.Filled.Layers,
      title = stringResource(R.string.perm_overlay_title),
      description = stringResource(R.string.perm_overlay_desc),
      isGranted = status.canDrawOverlays,
      testTag = "perm_overlay_button",
      onClick = onOpenOverlayPermission,
    )

    Spacer(modifier = Modifier.height(10.dp))

    PermissionActionRow(
      icon = Icons.Filled.Tune,
      title = stringResource(R.string.perm_write_title),
      description = stringResource(R.string.perm_write_desc),
      isGranted = status.canWriteSettings,
      testTag = "perm_write_settings_button",
      onClick = onOpenWriteSettingsPermission,
    )
  }
}

@Composable
private fun PermissionActionRow(
  icon: ImageVector,
  title: String,
  description: String,
  isGranted: Boolean,
  testTag: String,
  onClick: () -> Unit,
) {
  Surface(
    shape = RoundedCornerShape(12.dp),
    color = CyberSurfaceElevated,
    border =
      BorderStroke(
        1.dp,
        if (isGranted) CyberGreen.copy(alpha = 0.55f) else NeonRed.copy(alpha = 0.45f),
      ),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = if (isGranted) CyberGreen else ElectricCyan,
        modifier = Modifier.size(22.dp),
      )
      Spacer(modifier = Modifier.width(10.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = title,
          style = MaterialTheme.typography.titleMedium,
          fontSize = 13.5.sp,
          color = CyberTextPrimary,
        )
        Text(
          text = description,
          style = MaterialTheme.typography.bodyMedium,
          fontSize = 11.sp,
          color = CyberTextSecondary,
        )
      }
      Spacer(modifier = Modifier.width(8.dp))
      Button(
        onClick = onClick,
        enabled = !isGranted,
        shape = RoundedCornerShape(10.dp),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = NeonRed,
            contentColor = Color.White,
            disabledContainerColor = CyberGreenDark,
            disabledContentColor = CyberGreen,
          ),
        modifier = Modifier.height(40.dp).testTag(testTag),
      ) {
        if (isGranted) {
          Icon(
            imageVector = Icons.Filled.CheckCircle,
            contentDescription = null,
            modifier = Modifier.size(16.dp),
          )
          Spacer(modifier = Modifier.width(4.dp))
        } else {
          Icon(
            imageVector = Icons.Filled.Settings,
            contentDescription = null,
            modifier = Modifier.size(15.dp),
          )
          Spacer(modifier = Modifier.width(4.dp))
        }
        Text(
          text =
            if (isGranted) {
              stringResource(R.string.perm_status_granted)
            } else {
              stringResource(R.string.perm_status_pending)
            },
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold,
          fontSize = 11.sp,
        )
      }
    }
  }
}

@Composable
fun FloatingOverlayControlCard(
  isServiceRunning: Boolean,
  onToggleFloatingService: () -> Unit,
  onOpenFreeFire: () -> Unit,
  modifier: Modifier = Modifier,
) {
  CyberGlowCard(modifier = modifier, borderAccent = NeonRed) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Box(
        modifier =
          Modifier
            .size(38.dp)
            .background(CyberVoidBlack, CircleShape)
            .padding(2.dp),
        contentAlignment = Alignment.Center,
      ) {
        Surface(
          shape = CircleShape,
          color = CyberVoidBlack,
          border = BorderStroke(1.5.dp, NeonRed),
          modifier = Modifier.size(34.dp),
        ) {
          Box(contentAlignment = Alignment.Center) {
            Text(
              text = "RZ",
              color = NeonRed,
              fontFamily = FontFamily.Monospace,
              fontWeight = FontWeight.ExtraBold,
              fontSize = 13.sp,
            )
          }
        }
      }
      Spacer(modifier = Modifier.width(10.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = stringResource(R.string.floating_card_title),
          style = MaterialTheme.typography.titleMedium,
          color = CyberTextPrimary,
        )
        Text(
          text = stringResource(R.string.floating_card_desc),
          style = MaterialTheme.typography.bodyMedium,
          fontSize = 11.5.sp,
          color = CyberTextSecondary,
        )
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Button(
        onClick = onToggleFloatingService,
        shape = RoundedCornerShape(12.dp),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = if (isServiceRunning) CyberSurfaceElevated else NeonRed,
            contentColor = if (isServiceRunning) ElectricCyan else Color.White,
          ),
        border = if (isServiceRunning) BorderStroke(1.dp, ElectricCyan) else null,
        modifier = Modifier.weight(1f).height(48.dp).testTag("toggle_floating_rz_button"),
      ) {
        Text(
          text =
            if (isServiceRunning) {
              stringResource(R.string.floating_btn_stop)
            } else {
              stringResource(R.string.floating_btn_start)
            },
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold,
          fontSize = 11.sp,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }

      OutlinedButton(
        onClick = onOpenFreeFire,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, ElectricCyan),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = ElectricCyan),
        modifier = Modifier.height(48.dp).testTag("open_freefire_button"),
      ) {
        Icon(
          imageVector = Icons.Filled.SportsEsports,
          contentDescription = null,
          modifier = Modifier.size(18.dp),
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = stringResource(R.string.btn_open_freefire),
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold,
          fontSize = 11.sp,
        )
      }
    }
  }
}
