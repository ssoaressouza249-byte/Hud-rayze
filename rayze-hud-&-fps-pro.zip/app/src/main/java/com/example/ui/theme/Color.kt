package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberVoidBlack = Color(0xFF080A0F)
val CyberCardSurface = Color(0xFF121622)
val CyberSurfaceElevated = Color(0xFF192033)
val CyberSurfaceBorder = Color(0xFF28334E)

val NeonRed = Color(0xFFFF1744)
val NeonRedGlow = Color(0x4DFF1744)
val ElectricCyan = Color(0xFF00E5FF)
val ElectricCyanGlow = Color(0x4D00E5FF)

val CyberGreen = Color(0xFF00E676)
val CyberGreenDark = Color(0xFF0B2A1C)
val CyberAmber = Color(0xFFFFAB00)
val TamperLockRed = Color(0xFFB71C1C)

val CyberTextPrimary = Color(0xFFF5F8FF)
val CyberTextSecondary = Color(0xFF9BA7C4)
val CyberTextMuted = Color(0xFF6B7694)
