package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val CyberDarkColorScheme =
  darkColorScheme(
    primary = NeonRed,
    onPrimary = CyberTextPrimary,
    primaryContainer = CyberSurfaceElevated,
    onPrimaryContainer = NeonRed,
    secondary = ElectricCyan,
    onSecondary = CyberVoidBlack,
    secondaryContainer = CyberSurfaceElevated,
    onSecondaryContainer = ElectricCyan,
    tertiary = CyberGreen,
    onTertiary = CyberVoidBlack,
    background = CyberVoidBlack,
    onBackground = CyberTextPrimary,
    surface = CyberCardSurface,
    onSurface = CyberTextPrimary,
    surfaceVariant = CyberSurfaceElevated,
    onSurfaceVariant = CyberTextSecondary,
    outline = CyberSurfaceBorder,
    error = TamperLockRed,
    onError = CyberTextPrimary,
  )

private val CyberShapes =
  Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp),
  )

@Composable
fun RayzeCyberTheme(content: @Composable () -> Unit) {
  MaterialTheme(
    colorScheme = CyberDarkColorScheme,
    typography = CyberTypography,
    shapes = CyberShapes,
    content = content,
  )
}
