package com.example.core

import com.example.model.CrosshairColorOption
import com.example.model.CrosshairStyle
import com.example.model.RayzeSharedFlags
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * In-process reactive state store shared between MainActivity/ViewModel,
 * FloatingRayzeService, and RayzeDnsVpnService.
 */
object RayzeStateStore {
  private val _flags = MutableStateFlow(RayzeSharedFlags())
  val flags: StateFlow<RayzeSharedFlags> = _flags.asStateFlow()

  fun setLegitActivated(activated: Boolean) {
    _flags.update { it.copy(isLegitActivated = activated) }
  }

  fun setOverlayServiceRunning(running: Boolean) {
    _flags.update { it.copy(isOverlayServiceRunning = running) }
  }

  fun setCrosshairEnabled(enabled: Boolean) {
    _flags.update { it.copy(isCrosshairEnabled = enabled) }
  }

  fun setCrosshairStyle(style: CrosshairStyle) {
    _flags.update { it.copy(crosshairStyle = style) }
  }

  fun setCrosshairColor(color: CrosshairColorOption) {
    _flags.update { it.copy(crosshairColor = color) }
  }

  fun setTopMonitorEnabled(enabled: Boolean) {
    _flags.update { it.copy(isTopMonitorEnabled = enabled) }
  }

  fun setDnsVpnActive(active: Boolean) {
    _flags.update { it.copy(isDnsVpnActive = active) }
  }

  fun setLastRamCleanMessage(message: String?) {
    _flags.update { it.copy(lastRamCleanMessage = message) }
  }
}
