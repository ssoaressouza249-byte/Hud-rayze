package com.example.core

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.widget.Toast
import com.example.model.PermissionStatus
import com.example.model.TelemetryState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.InetAddress

object RayzeSystemController {
  // Settings.System.POINTER_SPEED maps to "pointer_speed" internally in Android framework.
  private const val SYSTEM_POINTER_SPEED_KEY = "pointer_speed"
  private const val TARGET_POINTER_SPEED = 7
  private const val FREE_FIRE_NORMAL_PKG = "com.dts.freefireth"
  private const val FREE_FIRE_MAX_PKG = "com.dts.freefiremax"

  fun checkPermissions(context: Context): PermissionStatus {
    val overlay = runCatching { Settings.canDrawOverlays(context) }.getOrDefault(false)
    val write = runCatching { Settings.System.canWrite(context) }.getOrDefault(false)
    return PermissionStatus(canDrawOverlays = overlay, canWriteSettings = write)
  }

  fun openOverlayPermission(context: Context) {
    runCatching {
      val intent =
        Intent(
          Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
          Uri.parse("package:${context.packageName}"),
        ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
      context.startActivity(intent)
    }
  }

  fun openWriteSettingsPermission(context: Context) {
    runCatching {
      val intent =
        Intent(
          Settings.ACTION_MANAGE_WRITE_SETTINGS,
          Uri.parse("package:${context.packageName}"),
        ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
      context.startActivity(intent)
    }
  }

  /**
   * Executes one internal calibration step out of 25 modules.
   * Applies native pointer_speed = 7 via WRITE_SETTINGS and cleans app cache safely.
   */
  suspend fun applyLegitCalibrationStep(
    context: Context,
    moduleIndex: Int,
  ): Pair<Boolean, Long> =
    withContext(Dispatchers.IO) {
      var pointerApplied = false
      var freedBytes = 0L

      if (moduleIndex == 12 || moduleIndex == 25) {
        pointerApplied =
          runCatching {
            if (Settings.System.canWrite(context)) {
              Settings.System.putInt(
                context.contentResolver,
                SYSTEM_POINTER_SPEED_KEY,
                TARGET_POINTER_SPEED,
              )
            } else {
              false
            }
          }.getOrDefault(false)
      }

      if (moduleIndex == 20) {
        freedBytes = clearAppCachesSafely(context)
      }

      Pair(pointerApplied, freedBytes / 1024L)
    }

  fun applyQuickLegitSettings(context: Context): Boolean {
    val applied =
      runCatching {
        if (Settings.System.canWrite(context)) {
          Settings.System.putInt(
            context.contentResolver,
            SYSTEM_POINTER_SPEED_KEY,
            TARGET_POINTER_SPEED,
          )
        } else {
          false
        }
      }.getOrDefault(false)
    clearAppCachesSafely(context)
    return applied
  }

  fun clearAppCachesSafely(context: Context): Long {
    var deletedBytes = 0L
    runCatching {
      deletedBytes += deleteDirectoryContents(context.cacheDir)
      deletedBytes += deleteDirectoryContents(context.codeCacheDir)
    }
    return deletedBytes
  }

  private fun deleteDirectoryContents(dir: File?): Long {
    if (dir == null || !dir.exists()) return 0L
    var freed = 0L
    runCatching {
      dir.listFiles()?.forEach { child ->
        if (child.isDirectory) {
          freed += deleteDirectoryContents(child)
          child.delete()
        } else {
          val len = child.length()
          if (child.delete()) {
            freed += len
          }
        }
      }
    }
    return freed
  }

  fun readMemoryAndBattery(context: Context): TelemetryState {
    var freeMb = 0L
    var totalMb = 0L
    var usedFraction = 0f

    runCatching {
      val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
      if (am != null) {
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)
        freeMb = memInfo.availMem / (1024L * 1024L)
        totalMb = memInfo.totalMem / (1024L * 1024L)
        if (totalMb > 0L) {
          usedFraction = ((totalMb - freeMb).toFloat() / totalMb.toFloat()).coerceIn(0f, 1f)
        }
      }
    }

    var tempC = 0f
    var batteryPct = 0
    runCatching {
      val batteryIntent =
        context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
      if (batteryIntent != null) {
        val rawTemp = batteryIntent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)
        tempC = rawTemp / 10f
        val level = batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = batteryIntent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        if (level >= 0 && scale > 0) {
          batteryPct = ((level * 100f) / scale.toFloat()).toInt().coerceIn(0, 100)
        }
      }
    }

    var thermalText = "Estável"
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      runCatching {
        val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        thermalText =
          when (pm?.currentThermalStatus) {
            PowerManager.THERMAL_STATUS_NONE -> "Frio / Ideal"
            PowerManager.THERMAL_STATUS_LIGHT -> "Leve"
            PowerManager.THERMAL_STATUS_MODERATE -> "Moderado"
            PowerManager.THERMAL_STATUS_SEVERE -> "Quente"
            PowerManager.THERMAL_STATUS_CRITICAL,
            PowerManager.THERMAL_STATUS_EMERGENCY,
            PowerManager.THERMAL_STATUS_SHUTDOWN -> "Crítico"
            else -> "Estável"
          }
      }
    }

    return TelemetryState(
      freeRamMb = freeMb,
      totalRamMb = totalMb,
      ramUsedFraction = usedFraction,
      batteryTempC = tempC,
      batteryLevelPct = batteryPct,
      thermalLabel = thermalText,
    )
  }

  /**
   * Measures real ping to Cloudflare 1.1.1.1 using InetAddress.isReachable(1000) on Dispatchers.IO.
   */
  suspend fun measureCloudflarePingMs(): Pair<Long?, Boolean> =
    withContext(Dispatchers.IO) {
      runCatching {
        val startMs = SystemClock.elapsedRealtime()
        val reachable = InetAddress.getByName("1.1.1.1").isReachable(1000)
        val elapsedMs = (SystemClock.elapsedRealtime() - startMs).coerceAtLeast(1L)
        if (reachable) {
          Pair(elapsedMs, true)
        } else {
          Pair(null, false)
        }
      }.getOrElse { Pair(null, false) }
    }

  /**
   * Cleans app caches, triggers JVM memory reclamation, and returns free RAM before & after (MB).
   */
  suspend fun optimizeFpsAndRam(context: Context): Pair<Long, Long> =
    withContext(Dispatchers.IO) {
      val beforeMb = readMemoryAndBattery(context).freeRamMb
      runCatching {
        clearAppCachesSafely(context)
        System.gc()
        Runtime.getRuntime().gc()
      }
      val afterMb = readMemoryAndBattery(context).freeRamMb
      Pair(beforeMb, afterMb)
    }

  fun launchFreeFire(context: Context): Boolean {
    return runCatching {
      val pm = context.packageManager
      val intent =
        pm.getLaunchIntentForPackage(FREE_FIRE_NORMAL_PKG)
          ?: pm.getLaunchIntentForPackage(FREE_FIRE_MAX_PKG)
      if (intent != null) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        true
      } else {
        Toast.makeText(
          context,
          "Free Fire (Normal ou MAX) não encontrado neste dispositivo.",
          Toast.LENGTH_SHORT,
        ).show()
        false
      }
    }.getOrDefault(false)
  }
}
