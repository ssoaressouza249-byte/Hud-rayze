package com.example

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.RayzeTab
import com.example.security.SecurityGuard
import com.example.security.TamperLockScreen
import com.example.ui.RayzeViewModel
import com.example.ui.components.FloatingOverlayControlCard
import com.example.ui.components.PermissionsCard
import com.example.ui.components.RayzeBrandBanner
import com.example.ui.screens.FpsPingTab
import com.example.ui.screens.LegitHudTab
import com.example.ui.theme.CyberCardSurface
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.CyberVoidBlack
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.NeonRed
import com.example.ui.theme.RayzeCyberTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    val securityCheck = SecurityGuard.verifyIntegrity(this)

    setContent {
      RayzeCyberTheme {
        if (!securityCheck.isValid) {
          TamperLockScreen(
            detectedPackage = securityCheck.detectedPackage,
            detectedLabel = securityCheck.detectedLabel,
            onUninstallClick = { SecurityGuard.launchUninstall(this@MainActivity) },
          )
        } else {
          RayzeMainScreen()
        }
      }
    }
  }
}

@Composable
fun RayzeMainScreen(viewModel: RayzeViewModel = viewModel()) {
  val state by viewModel.uiState.collectAsStateWithLifecycle()
  val context = LocalContext.current

  LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
    viewModel.refreshPermissions()
  }

  val vpnConsentLauncher =
    rememberLauncherForActivityResult(
      contract = ActivityResultContracts.StartActivityForResult(),
    ) { result ->
      if (result.resultCode == Activity.RESULT_OK) {
        viewModel.setDnsVpnEnabled(true)
      }
    }

  val handleToggleDnsVpn: (Boolean) -> Unit = remember(viewModel) {
    { enable ->
      if (!enable) {
        viewModel.setDnsVpnEnabled(false)
      } else {
        val consentIntent = viewModel.prepareVpnIntent()
        if (consentIntent != null) {
          runCatching { vpnConsentLauncher.launch(consentIntent) }
        } else {
          viewModel.setDnsVpnEnabled(true)
        }
      }
    }
  }

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    containerColor = CyberVoidBlack,
    contentWindowInsets = WindowInsets.safeDrawing,
    bottomBar = {
      Column(
        modifier =
          Modifier
            .fillMaxWidth()
            .background(CyberCardSurface)
            .windowInsetsPadding(WindowInsets.navigationBars),
      ) {
        NavigationBar(
          containerColor = CyberCardSurface,
          windowInsets = WindowInsets(0, 0, 0, 0),
        ) {
          NavigationBarItem(
            selected = state.selectedTab == RayzeTab.LEGIT_HUD,
            onClick = { viewModel.selectTab(RayzeTab.LEGIT_HUD) },
            icon = {
              Icon(
                imageVector = Icons.Filled.GpsFixed,
                contentDescription = stringResource(R.string.tab_legit_hud),
              )
            },
            label = {
              Text(
                text = stringResource(R.string.tab_legit_hud),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
              )
            },
            colors =
              NavigationBarItemDefaults.colors(
                selectedIconColor = NeonRed,
                selectedTextColor = NeonRed,
                indicatorColor = NeonRed.copy(alpha = 0.16f),
                unselectedIconColor = CyberTextSecondary,
                unselectedTextColor = CyberTextSecondary,
              ),
            modifier = Modifier.testTag("nav_tab_legit_hud"),
          )

          NavigationBarItem(
            selected = state.selectedTab == RayzeTab.FPS_PING,
            onClick = { viewModel.selectTab(RayzeTab.FPS_PING) },
            icon = {
              Icon(
                imageVector = Icons.Filled.Speed,
                contentDescription = stringResource(R.string.tab_fps_ping),
              )
            },
            label = {
              Text(
                text = stringResource(R.string.tab_fps_ping),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
              )
            },
            colors =
              NavigationBarItemDefaults.colors(
                selectedIconColor = ElectricCyan,
                selectedTextColor = ElectricCyan,
                indicatorColor = ElectricCyan.copy(alpha = 0.16f),
                unselectedIconColor = CyberTextSecondary,
                unselectedTextColor = CyberTextSecondary,
              ),
            modifier = Modifier.testTag("nav_tab_fps_ping"),
          )
        }

        // Bottom signature banner
        Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
          RayzeBrandBanner()
        }
      }
    },
  ) { innerPadding ->
    Box(
      modifier =
        Modifier
          .fillMaxSize()
          .padding(innerPadding),
      contentAlignment = Alignment.TopCenter,
    ) {
      Column(
        modifier =
          Modifier
            .widthIn(max = 640.dp)
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        // Top signature banner
        RayzeBrandBanner()

        // Native Permissions Card (Overlay + Write Settings)
        PermissionsCard(
          status = state.permissions,
          onOpenOverlayPermission = { viewModel.openOverlayPermission() },
          onOpenWriteSettingsPermission = { viewModel.openWriteSettingsPermission() },
        )

        // Floating Overlay Quick Control Card + Open Free Fire
        FloatingOverlayControlCard(
          isServiceRunning = state.sharedFlags.isOverlayServiceRunning,
          onToggleFloatingService = { viewModel.toggleFloatingOverlayService() },
          onOpenFreeFire = { viewModel.launchFreeFire() },
        )

        // Active Tab Content
        when (state.selectedTab) {
          RayzeTab.LEGIT_HUD ->
            LegitHudTab(
              legitState = state.legitState,
              selectedWeapon = state.selectedWeapon,
              fireButtonSizePct = state.fireButtonSizePct,
              swipeMetric = state.swipeMetric,
              onActivateLegit = { viewModel.activateLegitCode() },
              onSelectWeapon = { viewModel.selectWeaponPreset(it) },
              onFireButtonSizeChange = { viewModel.updateFireButtonSize(it) },
              onLiveSwipeUpdate = { pts, ms -> viewModel.updateSwipeLiveTrail(pts, ms) },
              onSwipeFinished = { pts, ms -> viewModel.finalizeSwipe(pts, ms) },
            )

          RayzeTab.FPS_PING ->
            FpsPingTab(
              telemetry = state.telemetry,
              isDnsVpnActive = state.sharedFlags.isDnsVpnActive,
              isOptimizingRam = state.isOptimizingRam,
              ramOptimizationSummary = state.ramOptimizationSummary,
              onToggleDnsVpn = handleToggleDnsVpn,
              onOptimizeFpsAndRam = { viewModel.optimizeFpsAndRam() },
            )
        }
      }
    }
  }
}
