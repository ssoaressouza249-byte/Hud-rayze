package com.example.model

enum class RayzeTab {
  LEGIT_HUD,
  FPS_PING,
}

enum class CrosshairStyle(val label: String) {
  PONTO("Ponto"),
  CRUZ("Cruz"),
  CIRCULO("Círculo"),
}

enum class CrosshairColorOption(val label: String, val argb: Int) {
  NEON_RED("Vermelho", 0xFFFF1744.toInt()),
  ELECTRIC_CYAN("Ciano", 0xFF00E5FF.toInt()),
  NEON_GREEN("Verde", 0xFF00E676.toInt()),
}

data class WeaponPreset(
  val id: String,
  val name: String,
  val category: String,
  val geral: Int,
  val pontoVermelho: Int,
  val mira2x: Int,
  val mira4x: Int,
  val awm: Int,
  val olhadinha: Int,
  val dpiRecomendada: Int,
  val tamanhoBotaoPct: Int,
  val tip: String,
)

object WeaponPresetCatalog {
  val presets: List<WeaponPreset> =
    listOf(
      WeaponPreset(
        id = "desert",
        name = "Desert Eagle",
        category = "1-Tap / Pistola",
        geral = 196,
        pontoVermelho = 188,
        mira2x = 175,
        mira4x = 168,
        awm = 120,
        olhadinha = 140,
        dpiRecomendada = 580,
        tamanhoBotaoPct = 52,
        tip = "Puxada curta e reta para cima buscando 1-tap preciso na cabeça.",
      ),
      WeaponPreset(
        id = "m1014",
        name = "M1014",
        category = "Doze / Curta Distância",
        geral = 200,
        pontoVermelho = 192,
        mira2x = 180,
        mira4x = 172,
        awm = 115,
        olhadinha = 150,
        dpiRecomendada = 620,
        tamanhoBotaoPct = 58,
        tip = "Subida explosiva em J invertido curto para grudar em curta distância.",
      ),
      WeaponPreset(
        id = "mp40",
        name = "MP40",
        category = "SMG / Alta Cadência",
        geral = 194,
        pontoVermelho = 186,
        mira2x = 182,
        mira4x = 174,
        awm = 124,
        olhadinha = 145,
        dpiRecomendada = 560,
        tamanhoBotaoPct = 50,
        tip = "Controle contínuo vertical evitando que a rajada passe acima da cabeça.",
      ),
      WeaponPreset(
        id = "ump",
        name = "UMP",
        category = "SMG / Versátil",
        geral = 190,
        pontoVermelho = 182,
        mira2x = 186,
        mira4x = 178,
        awm = 128,
        olhadinha = 138,
        dpiRecomendada = 520,
        tamanhoBotaoPct = 48,
        tip = "Estabilidade equilibrada para média distância e trocação rápida.",
      ),
      WeaponPreset(
        id = "carapina",
        name = "Carapina",
        category = "AR / Semiautomática",
        geral = 185,
        pontoVermelho = 176,
        mira2x = 188,
        mira4x = 184,
        awm = 135,
        olhadinha = 130,
        dpiRecomendada = 490,
        tamanhoBotaoPct = 46,
        tip = "Toque firme e micro-ajuste vertical para encaixar 2x e 4x.",
      ),
    )
}

data class PermissionStatus(
  val canDrawOverlays: Boolean = false,
  val canWriteSettings: Boolean = false,
)

sealed interface LegitActivationState {
  data object Idle : LegitActivationState

  data class Activating(
    val progressPercent: Int,
    val completedModules: Int,
    val totalModules: Int = 25,
  ) : LegitActivationState

  data class Activated(
    val pointerSpeedApplied: Boolean,
    val cleanedCacheKb: Long,
  ) : LegitActivationState
}

data class SwipeSamplePoint(val x: Float, val y: Float)

data class SwipeMetricResult(
  val durationMs: Long = 0L,
  val straightnessPercent: Int = 0,
  val upwardDistanceDp: Float = 0f,
  val hasMeasurement: Boolean = false,
  val trail: List<SwipeSamplePoint> = emptyList(),
)

data class TelemetryState(
  val freeRamMb: Long = 0L,
  val totalRamMb: Long = 0L,
  val ramUsedFraction: Float = 0f,
  val batteryTempC: Float = 0f,
  val batteryLevelPct: Int = 0,
  val pingMs: Long? = null,
  val pingReachable: Boolean = false,
  val isPingChecking: Boolean = true,
  val thermalLabel: String = "Normal",
)

data class RayzeSharedFlags(
  val isLegitActivated: Boolean = false,
  val isOverlayServiceRunning: Boolean = false,
  val isCrosshairEnabled: Boolean = false,
  val crosshairStyle: CrosshairStyle = CrosshairStyle.CRUZ,
  val crosshairColor: CrosshairColorOption = CrosshairColorOption.NEON_RED,
  val isTopMonitorEnabled: Boolean = false,
  val isDnsVpnActive: Boolean = false,
  val lastRamCleanMessage: String? = null,
)
