package com.example.security

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.TamperLockRed

object SecurityGuard {
  const val EXPECTED_PACKAGE_NAME = "com.raylan.rayzehudfps"
  const val EXPECTED_NAME_TOKEN = "Rayze HUD"

  data class VerificationResult(
    val isValid: Boolean,
    val detectedPackage: String,
    val detectedLabel: String,
  )

  fun verifyIntegrity(context: Context): VerificationResult {
    val pkg = runCatching { context.packageName }.getOrDefault("")
    val appLabel =
      runCatching {
        context.applicationInfo.loadLabel(context.packageManager).toString()
      }.getOrDefault("")
    val resourceLabel =
      runCatching { context.getString(R.string.app_name) }.getOrDefault("")

    val packageOk = pkg == EXPECTED_PACKAGE_NAME
    val nameOk =
      appLabel.contains(EXPECTED_NAME_TOKEN, ignoreCase = false) &&
        resourceLabel.contains(EXPECTED_NAME_TOKEN, ignoreCase = false)

    return VerificationResult(
      isValid = packageOk && nameOk,
      detectedPackage = pkg,
      detectedLabel = appLabel.ifBlank { resourceLabel },
    )
  }

  fun launchUninstall(context: Context) {
    runCatching {
      val uninstallIntent =
        Intent(Intent.ACTION_DELETE).apply {
          data = Uri.parse("package:${context.packageName}")
          addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
      context.startActivity(uninstallIntent)
    }
  }
}

@Composable
fun TamperLockScreen(
  detectedPackage: String,
  detectedLabel: String,
  onUninstallClick: () -> Unit,
) {
  BackHandler(enabled = true) {}

  Box(
    modifier =
      Modifier
        .fillMaxSize()
        .background(TamperLockRed)
        .safeDrawingPadding()
        .padding(24.dp),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      modifier = Modifier.widthIn(max = 520.dp).fillMaxWidth(),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
    ) {
      Surface(
        shape = RoundedCornerShape(24.dp),
        color = Color(0x33000000),
        modifier = Modifier.size(96.dp),
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = Icons.Filled.Warning,
            contentDescription = stringResource(R.string.tamper_title),
            tint = Color.White,
            modifier = Modifier.size(56.dp),
          )
        }
      }

      Spacer(modifier = Modifier.height(24.dp))

      Text(
        text = stringResource(R.string.tamper_title),
        color = Color.White,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 24.sp,
        textAlign = TextAlign.Center,
      )

      Spacer(modifier = Modifier.height(14.dp))

      Text(
        text = stringResource(R.string.tamper_message),
        color = Color(0xFFFFEBEE),
        style = MaterialTheme.typography.bodyLarge,
        textAlign = TextAlign.Center,
      )

      Spacer(modifier = Modifier.height(16.dp))

      Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0x44000000),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(
          modifier = Modifier.padding(14.dp),
          verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          Text(
            text = "ID: $detectedPackage",
            color = Color.White,
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
          )
          Text(
            text = "Nome: $detectedLabel",
            color = Color.White,
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
          )
        }
      }

      Spacer(modifier = Modifier.height(28.dp))

      Button(
        onClick = onUninstallClick,
        colors =
          ButtonDefaults.buttonColors(
            containerColor = Color.White,
            contentColor = TamperLockRed,
          ),
        shape = RoundedCornerShape(14.dp),
        modifier =
          Modifier
            .fillMaxWidth()
            .height(56.dp)
            .testTag("tamper_uninstall_button"),
      ) {
        Icon(
          imageVector = Icons.Filled.DeleteForever,
          contentDescription = null,
          modifier = Modifier.size(22.dp),
        )
        Spacer(modifier = Modifier.size(10.dp))
        Text(
          text = stringResource(R.string.tamper_uninstall),
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.ExtraBold,
          fontSize = 15.sp,
        )
      }
    }
  }
}
